from setuptools import setup, find_packages

# Чтение README.md
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="PythonRus",
    version="0.1.0",
    author="Слава Берн",
    author_email="bernslava3@gmail.com",
    description="Библиотека заменяющая английские команды на русский язык",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ]
)