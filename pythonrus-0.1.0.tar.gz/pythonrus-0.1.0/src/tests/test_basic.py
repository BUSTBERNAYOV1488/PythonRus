import pytest
from pythonrus import Нарисовать, Линия, Прямоугольник, Треугольник, Рамка, ПрогрессБар, СИМВОЛЫ
from io import StringIO
import sys

# 1. Тестирование функции Нарисовать (аналог print)
def test_нарисовать(capsys):  # capsys - встроенная фикстура pytest для перехвата вывода
    """Проверяет, что функция Нарисовать выводит правильный текст"""
    test_text = "Тестовый текст"
    Нарисовать(test_text)
    captured = capsys.readouterr()  # Перехватываем то, что было напечатано
    assert captured.out.strip() == test_text  # .strip() убирает лишние переносы строк

# 2. Тестирование функции Линия
def test_линия_по_умолчанию(capsys):
    """Проверяет линию с параметрами по умолчанию"""
    Линия()
    captured = capsys.readouterr()
    assert captured.out.strip() == '-' * 20  # Должна быть линия из 20 дефисов

def test_линия_с_параметрами(capsys):
    """Проверяет линию с кастомными параметрами"""
    length = 5
    char = '='
    Линия(length, char)
    captured = capsys.readouterr()
    assert captured.out.strip() == '=' * 5  # Должна быть линия "====="

# 3. Тестирование функции Прямоугольник
def test_прямоугольник_размером_3x3(capsys):
    """Проверяет отрисовку маленького прямоугольника"""
    expected_output = "***\n* *\n***"  # Ожидаемый вывод
    Прямоугольник(3, 3)
    captured = capsys.readouterr()
    # Сравниваем без учета пробелов в конце строк
    assert captured.out.strip().replace(' ', '') == expected_output.replace(' ', '')

# 4. Тестирование функции Рамка
def test_рамка(capsys):
    """Проверяет, что текст правильно обрамляется"""
    text = "Привет"
    Рамка(text, '#')
    captured = capsys.readouterr()
    lines = captured.out.strip().split('\n')
    
    # Проверяем, что получилось 3 строки
    assert len(lines) == 3
    # Проверяем верхнюю и нижнюю линии
    assert lines[0] == '#' * (len(text) + 4)
    assert lines[2] == '#' * (len(text) + 4)
    # Проверяем среднюю строку с текстом
    assert lines[1] == f"# {text} #"

# 5. Тестирование функции ПрогрессБар
def test_прогрессбар_50_percent(capsys):
    """Проверяет заполнение прогресс-бара на 50%"""
    ПрогрессБар(50, длина=10)
    captured = capsys.readouterr()
    # Должна быть строка вида "[█████░░░░░] 50%"
    assert "50%" in captured.out
    # Проверяем, что длина бара равна 10 символам (без учета скобок и процентов)
    bar_start = captured.out.find('[')
    bar_end = captured.out.find(']')
    bar_content = captured.out[bar_start+1:bar_end]
    assert len(bar_content) == 10

def test_прогрессбар_граничные_значения(capsys):
    """Проверяет 0% и 100%"""
    ПрогрессБар(0)
    captured = capsys.readouterr()
    assert "0%" in captured.out
    
    ПрогрессБар(100)
    captured = capsys.readouterr()
    assert "100%" in captured.out

# 6. Тестирование словаря СИМВОЛЫ
def test_специальные_символы():
    """Проверяет, что словарь специальных символов не пустой и содержит нужные ключи"""
    assert isinstance(СИМВОЛЫ, dict)  # Это точно словарь?
    assert len(СИМВОЛЫ) > 0  # Он не пустой?
    # Проверяем наличие ожидаемых ключей
    expected_keys = ['квадрат', 'круг', 'ромб', 'сердце', 'звезда']
    for key in expected_keys:
        assert key in СИМВОЛЫ
    # Проверяем, что значения - это непустые строки
    for value in СИМВОЛЫ.values():
        assert isinstance(value, str)
        assert len(value) > 0

# 7. Тест на ошибки (опционально, но очень важно)
def test_прогрессбар_отрицательное_значение(capsys):
    """Проверяет, как функция behaves при отрицательном проценте"""
    # Вместо assert проверяем, что не падает с ошибкой
    # Можно проверить, что выводит 0% или как-то иначе обрабатывает
    ПрогрессБар(-10)
    captured = capsys.readouterr()
    # Хотя бы проверяем, что что-то вывелось и не упало
    assert len(captured.out) > 0

# Запуск тестов: в терминале из папки проекта выполнить `pytest`