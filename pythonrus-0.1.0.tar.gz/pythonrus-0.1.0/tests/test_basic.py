import sys
import os
import pytest
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.pythonrus import Линия, Рамка, ПрогрессБар, СИМВОЛЫ

def test_линия(capsys):
    """Тест функции Линия"""
    Линия(5, '*')
    captured = capsys.readouterr()
    assert captured.out.strip() == '*****'

def test_рамка(capsys):
    """Тест функции Рамка"""
    Рамка("тест", '#')
    captured = capsys.readouterr()
    lines = captured.out.strip().split('\n')
    assert len(lines) == 3
    assert 'тест' in lines[1]

def test_символы():
    """Тест словаря символов"""
    assert 'сердце' in СИМВОЛЫ
    assert СИМВОЛЫ['сердце'] == '♥'
